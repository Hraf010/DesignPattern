import compression.CompressionAbstract;
import compression.CompressionImpl1;
import filtrage.FiltrageImpl1;
import filtrage.FiltrageImpl2;
import filtrage.TraitementFitrage;

import java.util.Scanner;

public class Main {
    static TraitementFitrage loadFiltrageClass(String name) throws Exception {
        Class implementationClass = Class.forName(name);
        return (TraitementFitrage) implementationClass.newInstance();
    }

    static CompressionAbstract loadCompressionClass(String name) throws Exception {
        Class CompressionClass = Class.forName(name);
        return (CompressionAbstract) CompressionClass.newInstance();
    }
    public static void main(String[] args) throws Exception {

        int[] data = { 1, 2, 3 , 4 };
        Framework framework = new Framework();

        Scanner sc = new Scanner(System.in);
        System.out.println("Entrez le nom d'implémentation du filtre");
        String filterName = sc.nextLine();
        TraitementFitrage filter = loadFiltrageClass(filterName);
        filter.filter(data);

        System.out.println("Entrez le nom d'implémentation du compression");
        String compressionName = sc.nextLine();
        CompressionAbstract compressionAbstract = loadCompressionClass(compressionName);
        compressionAbstract.compresser(data);


    }
}
