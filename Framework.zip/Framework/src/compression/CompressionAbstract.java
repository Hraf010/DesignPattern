package compression;

public abstract class CompressionAbstract {
    public int[] compresser(int[] data){
        System.out.println("some code");
        partie1abs();
        partie2abs();
        System.out.println("some code");
        return null;
    }

    protected abstract void partie1abs();
    protected abstract void partie2abs();
}
