package compression;

 public class CompressionImpl2 extends CompressionAbstract {
    @Override
    protected void partie1abs() {
        System.out.println("Partie 1 implementation 1");
    }

    @Override
    protected void partie2abs() {
        System.out.println("Partie 2 implementation 1");
    }
}
