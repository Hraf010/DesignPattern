package compression;

public class CompressionImpl1 extends CompressionAbstract {
    @Override
    protected void partie1abs() {
        System.out.println("Partie 1 implementation 2");
    }

    @Override
    protected void partie2abs() {
        System.out.println("Partie 2 implementation 2");
    }
}
