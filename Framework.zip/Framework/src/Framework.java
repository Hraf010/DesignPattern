import compression.CompressionAbstract;
import filtrage.FiltrageImpl1;
import filtrage.FiltrageImpl2;
import filtrage.TraitementFitrage;

public class Framework {
    private TraitementFitrage traitementFitrage;
    private CompressionAbstract compressionAbstract;


    public CompressionAbstract getCompressionAbstract() {
        return compressionAbstract;
    }

    public void setCompressionAbstract(CompressionAbstract compressionAbstract) {
        this.compressionAbstract = compressionAbstract;
    }

    public TraitementFitrage getTraitementFitrage() {
        return traitementFitrage;
    }

    public void setTraitementFitrage(TraitementFitrage traitementFitrage) {
        this.traitementFitrage = traitementFitrage;
    }

    public  int[]  filter(int[] data){
       return this.traitementFitrage.filter(data);
    }

    public int[] compresser(int[] data){
        return this.compressionAbstract.compresser(data);
    }

}
