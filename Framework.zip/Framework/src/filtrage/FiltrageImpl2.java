package filtrage;

public class FiltrageImpl2 implements TraitementFitrage {
    @Override
    public int[] filter(int[] data) {
        System.out.println("*******************");
        System.out.println("filter 1");
        return null;
    }
}
