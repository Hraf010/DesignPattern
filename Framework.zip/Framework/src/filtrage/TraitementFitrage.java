package filtrage;

public interface TraitementFitrage {
    public  int[] filter(int[] data);
}
