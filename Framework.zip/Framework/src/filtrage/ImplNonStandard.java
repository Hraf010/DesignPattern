package filtrage;

public class ImplNonStandard {
	
	public int[] appliquerFiltre(String filterName, int[] data) {
		System.out.println(" non standard filter implementation");
		System.out.println("Non standard implementation , the filter :"+filterName);
		return null;
	}
}
