package filtrage;

public class Adapter implements TraitementFitrage{
	
	private ImplNonStandard implNonStandard = new ImplNonStandard();

	@Override
	public int[] filter(int[] data) {
		return implNonStandard.appliquerFiltre("non standard filter", data);
	}

}
