package filtrage;

public class FiltrageImpl1 implements TraitementFitrage {
    @Override
    public int[] filter(int[] data) {
        System.out.println("*******************");
        System.out.println("filter 2");
        return null;
    }
}
